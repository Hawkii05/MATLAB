function alt = stabilization_altitude(VD, altitude_above_PI)
    alt = altitude_above_PI - VD;
end