function FTD = forward_travel_distance(forward_travel_time, ground_speed)
FTD = (forward_travel_time * ground_speed)/1.78;
end