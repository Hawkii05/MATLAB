function t = total_time_of_fall(TFC, time_of_fall)
t = TFC + time_of_fall;
end