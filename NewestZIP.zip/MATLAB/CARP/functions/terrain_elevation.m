function alt = terrain_elevation(terrain_elevation)
alt = terrain_elevation; % Assign input to output variable
end