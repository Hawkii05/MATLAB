function FTT = forward_travel_time(DQ, exit_time)
    FTT = exit_time + DQ;
end