function alt = true_altitude(drop_altitude,terrain_elevation)
    alt = drop_altitude - terrain_elevation;
end