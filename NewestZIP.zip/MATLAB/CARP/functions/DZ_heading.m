function deg = DZ_heading(drift_correction, DZ_course)
    deg