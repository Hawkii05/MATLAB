function Q = DynamicPressure(rho, V)
    Q = 1/2*rho*V^2;
end

