function mi = m2mi(m)
    mi = m * 0.000621371;
end