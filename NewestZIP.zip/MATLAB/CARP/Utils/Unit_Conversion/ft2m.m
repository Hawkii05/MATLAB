function m = ft2m(ft)
    m = ft * 0.3048;
end