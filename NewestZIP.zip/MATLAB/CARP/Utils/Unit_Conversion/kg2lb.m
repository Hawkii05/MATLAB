function lb = kg2lb(kg)
    lb = kg * 2.20462;
end