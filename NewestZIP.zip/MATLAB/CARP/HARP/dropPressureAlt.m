function presAlt_ft = dropPressureAlt(dropIndicatedTrueAlt_ft, PAV_ft)
% dropPressureAlt: Item 3 = Item1 + Item2
presAlt_ft = dropIndicatedTrueAlt_ft + PAV_ft;
end
